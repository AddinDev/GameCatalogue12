//
//  Game.swift
//  GameCatalalogue
//
//  Created by addjn on 29/09/20.
//

import Foundation

struct Games: Decodable {
    var results: [Game]
}

struct Game: Identifiable, Decodable {
    let id = UUID()
    let gameId: Int
    let name, released: String
    let backgroundImage: String
    let rating: Double


    enum CodingKeys: String, CodingKey {
        case gameId = "id"
        case name, released
        case backgroundImage = "background_image"
        case rating
    }
}

struct SearchGames: Decodable {
    var results: [SearchGame]
}

struct SearchGame: Identifiable, Decodable {
    let id = UUID()
    let gameId: Int
    let name: String
    let released: String?
    let backgroundImage: String?
    let rating: Double

    enum CodingKeys: String, CodingKey {
        case name, released
        case backgroundImage = "background_image"
        case rating
        case gameId = "id"
        
    }
}

struct Desc: Decodable {
    var description: String
}

