//
//  Networking.swift
//  GameCatalalogue
//
//  Created by addjn on 29/09/20.
//

import Foundation
import Alamofire

class Networking: ObservableObject {
    @Published var games = [Game]()
    @Published var searchGame = [SearchGame]()
    @Published var description = String()
    
        func getData() {
            _ = getInfo
        }
    
        private lazy var getInfo: Void = {
            AF.request("https://api.rawg.io/api/games")
                .responseDecodable(of: Games.self) { response in
                    guard let value = response.value else { return }
                    self.games = value.results
    
                }
        }()
    
    func getSearch(word: String) {
        AF.request("https://api.rawg.io/api/games?search=\(word)")
            .responseDecodable(of: SearchGames.self) { response in
                guard let value = response.value else { return }
                self.searchGame = value.results
            }
    }
    
        func getDesc(gameId: String) {
            AF.request("https://api.rawg.io/api/games/\(gameId)")
                .responseDecodable(of: Desc.self) { response in
                    guard let value = response.value else { return }
                    
                    let word = value.description
                    
                    let a = word.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
                    let result = a.replacingOccurrences(of: "&[^;]+;", with: "", options: String.CompareOptions.regularExpression, range: nil)
                    self.description = result
                }
        }
}


