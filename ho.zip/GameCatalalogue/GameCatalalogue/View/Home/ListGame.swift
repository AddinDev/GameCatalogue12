//
//  ListGame.swift
//  GameCatalogue
//
//  Created by addjn on 29/09/20.
//

import SwiftUI
import URLImage

struct ListGame: View {
    var game: Game
    var body: some View {
        HStack {
            URLImage(URL(string: game.backgroundImage)!, placeholder: Image(systemName: "capsule")) { proxy in
                proxy.image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            }
            .frame(width: 75, height: 75)
            .cornerRadius(10)

            VStack(alignment: .leading) {
                Text(game.name)
                HStack {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                    Text(String(game.rating))
                }
            }
        }
        .padding(7)
    }
}

//struct ListGame_Previews: PreviewProvider {
//    static var previews: some View {
//        ListGame()
//    }
//}
