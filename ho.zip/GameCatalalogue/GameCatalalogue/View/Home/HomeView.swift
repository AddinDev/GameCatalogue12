//
//  HomeView.swift
//  GameCatalogue
//
//  Created by addjn on 29/09/20.
//

import SwiftUI

struct HomeView: View {
    @ObservedObject var networking = Networking()
    var body: some View {
        NavigationView {
            List(networking.games) { game in
                NavigationLink(destination: DetailView(game: game)) {
                    ListGame(game: game)
                }
            }
            .onAppear {
                self.networking.getData()
            }
            .navigationTitle("Games")
            .navigationBarItems(trailing:
                                    Button(action: {
                                        print("A")
                                    }) {
                                        Image(systemName: "gear")
                                    }
            )
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
