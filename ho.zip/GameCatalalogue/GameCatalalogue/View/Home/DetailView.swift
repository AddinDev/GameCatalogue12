//
//  DetailView.swift
//  GameCatalogue
//
//  Created by addjn on 29/09/20.
//

import SwiftUI
import URLImage

struct DetailView: View {
    @FetchRequest(entity: FavGame.entity(), sortDescriptors: []) var favGames: FetchedResults<FavGame>
    @Environment(\.managedObjectContext) var moc
    
    @ObservedObject var networking = Networking()
    var game: Game
    var body: some View {
        ScrollView {
            VStack {
                URLImage(URL(string: game.backgroundImage)!, placeholder: Image(systemName: "capsule")) { proxy in
                    proxy.image
                        .resizable()
                }
                .frame(height: 200)
                
                HStack {
                    HStack {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                        Text(String(game.rating))
                    }
                    
                    Spacer()
                    
                    VStack {
                        Text("Released")
                        Text(game.released)
                    }
                }
                .padding()
                
                VStack(spacing: 8) {
                    Text("Description")
                    Text(networking.description)
                }.padding()

            }
        }
        .navigationTitle(game.name)
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarItems(trailing: Button("add") {self.saveGame()})
        .onAppear {
            self.networking.getDesc(gameId: String(game.gameId))
        }
    }
    
    func saveGame() {
        let favGame = FavGame(context: self.moc)
        favGame.id = UUID()
        favGame.gameId = String(self.game.gameId)
        favGame.name = self.game.name
        favGame.released = self.game.released
        favGame.backgroundImage = self.game.backgroundImage
        favGame.rating = self.game.rating
        
        try? self.moc.save()
    }
    
}

//struct DetailView_Previews: PreviewProvider {
//    static var previews: some View {
//        DetailView()
//    }
//}
