//
//  ListSGame.swift
//  GameCatalogue
//
//  Created by addjn on 29/09/20.
//

import SwiftUI
import URLImage

struct ListSGame: View {
    var game: SearchGame
    var body: some View {
        HStack {
            URLImage(URL(string: game.backgroundImage ?? "https://www.google.com/url?sa=i&url=https%3A%2F%2Fnews.olx.co.id%2F&psig=AOvVaw2_YfH_jMKI3ezDmXV3a5VD&ust=1601439082534000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMjYjtW_jewCFQAAAAAdAAAAABAD")!, placeholder: Image(systemName: "capsule")) { proxy in
                proxy.image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            }
            .frame(width: 75, height: 75)
            .cornerRadius(10)

            VStack(alignment: .leading) {
                Text(game.name)
                HStack {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                    Text(String(game.rating))
                }
            }
        }
        .padding(7)
    }
}

//struct ListSGame_Previews: PreviewProvider {
//    static var previews: some View {
//        ListSGame()
//    }
//}
