//
//  SearchView.swift
//  GameCatalogue
//
//  Created by addjn on 29/09/20.
//

import SwiftUI

struct SearchView: View {
    @ObservedObject var networking = Networking()
    @State var word = ""
    @State var pressed = false
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    TextField("search games...", text: $word, onCommit: {
                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                        self.networking.getSearch(word: word)
                        withAnimation() {
                            self.pressed = false
                        }
                    })
                    .padding(10)
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                    .padding()
                    .onTapGesture(perform: {
                        withAnimation() {
                            self.pressed = true
                        }
                    })
                    if self.pressed {
                        Button("cancel") {
                            self.word = ""
                            withAnimation() {
                                self.pressed = false
                            }
                            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                        }
                    } else {
                        
                    }
                    
                }
                .padding(.horizontal)
                
                List(networking.searchGame) { game in
                    NavigationLink(destination: DetailSView(game: game)) {
                        ListSGame(game: game)
                    }
                }
            }
            .navigationTitle("Search")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}
