//
//  DetailSView.swift
//  GameCatalogue
//
//  Created by addjn on 29/09/20.
//

import SwiftUI
import URLImage

struct DetailSView: View {
    @ObservedObject var networking = Networking()
    var game: SearchGame
    var body: some View {
        ScrollView {
            VStack {
                URLImage(URL(string: game.backgroundImage ?? "https://www.google.com/url?sa=i&url=https%3A%2F%2Fnews.olx.co.id%2F&psig=AOvVaw2_YfH_jMKI3ezDmXV3a5VD&ust=1601439082534000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMjYjtW_jewCFQAAAAAdAAAAABAD")!, placeholder: Image(systemName: "capsule")) { proxy in
                    proxy.image
                        .resizable()
                }
                .frame(height: 200)
                
                HStack {
                    HStack {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                        Text(String(game.rating))
                    }
                    
                    Spacer()
                    
                    VStack {
                        Text("Released")
                        Text(game.released ?? "")
                    }
                }
                .padding()
                
                VStack(spacing: 8) {
                    Text("Description")
                    Text(networking.description)
                }.padding()
                
            }
        }
        .navigationTitle(game.name)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            self.networking.getDesc(gameId: String(game.gameId))
        }
    }
}

//struct DetailSView_Previews: PreviewProvider {
//    static var previews: some View {
//        DetailSView()
//    }
//}
