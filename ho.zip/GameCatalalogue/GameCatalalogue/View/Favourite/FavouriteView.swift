//
//  FavouriteView.swift
//  GameCatalalogue
//
//  Created by addjn on 29/09/20.
//

import SwiftUI

struct FavouriteView: View {
    @Environment(\.managedObjectContext) var moc
    @FetchRequest(entity: FavGame.entity(), sortDescriptors: []) var favGame: FetchedResults<FavGame>
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(favGame, id: \.id) { game in
                        NavigationLink(destination: DetailFView(game: game)) {
                            ListFGame(game: game)
                        }
                    }
                    .onDelete(perform: delete)
                }
                .navigationBarTitle("Favourite", displayMode: .inline)
                .navigationBarItems(leading: EditButton())
            }
            .onAppear {
                try? self.moc.save()
            }
        }
    }
    func delete(at offsets: IndexSet) {
        for offset in offsets {
            let game = favGame[offset]
            moc.delete(game)
        }
        try? moc.save()
    }
}

struct FavouriteView_Previews: PreviewProvider {
    static var previews: some View {
        FavouriteView()
    }
}
